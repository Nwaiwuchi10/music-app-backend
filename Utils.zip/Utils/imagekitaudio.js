const ImageKitaudio = require("imagekit");

const imagekitaudio = new ImageKitaudio({
  publicKey: "public_tngjmq08qzbREcFl7s+Avy1wYdo=",
  privateKey: "private_MPowOnFb/tmnxoVd+Q1c3RQrd1Q=",
  urlEndpoint: "https://ik.imagekit.io/wgbw0oopk2/",
});

module.exports = imagekitaudio;
