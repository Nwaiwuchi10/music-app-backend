const ImageKitVideo = require("imagekit");

const imagekitvideo = new ImageKitVideo({
  publicKey: "public_7/wKlxYgTL8Q69dEw5K2BjYmS8A=",
  privateKey: "private_BRV48z+o1h0xmX6tmhmhFLUoJ5c=",
  urlEndpoint: "https://ik.imagekit.io/bf2rpjupk",
});

module.exports = imagekitvideo;
