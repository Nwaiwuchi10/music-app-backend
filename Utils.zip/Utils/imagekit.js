const ImageKit = require("imagekit");

const imagekit = new ImageKit({
  publicKey: "public_tngjmq08qzbREcFl7s+Avy1wYdo=",
  privateKey: "private_MPowOnFb/tmnxoVd+Q1c3RQrd1Q=",
  urlEndpoint: "https://ik.imagekit.io/wgbw0oopk2/",
});

module.exports = imagekit;
